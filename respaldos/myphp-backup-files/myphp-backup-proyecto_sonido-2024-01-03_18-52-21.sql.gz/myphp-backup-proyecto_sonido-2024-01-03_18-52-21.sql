SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `tb_administrador`;

CREATE TABLE `tb_administrador` (
  `id_administrador` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_administrador` varchar(50) DEFAULT NULL,
  `apellido_administrador` varchar(50) DEFAULT NULL,
  `telefono_administrador` int(11) DEFAULT NULL,
  `user_admin` varchar(50) DEFAULT NULL,
  `password_admin` varchar(50) DEFAULT NULL,
  `estado_admin` varchar(20) DEFAULT NULL,
  `observacion_admin` text DEFAULT NULL,
  PRIMARY KEY (`id_administrador`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_administrador` VALUES (1,"Admin","administrador",67676787,"admin123","admin123","Activo","Es el administrador del sistema");


DROP TABLE IF EXISTS `tb_categoria`;

CREATE TABLE `tb_categoria` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_categoria` varchar(50) DEFAULT NULL,
  `estado_cat` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_categoria` VALUES (1,"TECLADOS-MUSICA","Activo"),
(2,"TECLADOS-CPU","Activo"),
(3,"PARLANTES","Activo"),
(4,"MOUSE","Activo"),
(5,"ADAPTADOR WIFI","Activo");


DROP TABLE IF EXISTS `tb_cierre_caja`;

CREATE TABLE `tb_cierre_caja` (
  `id_cierre_caja` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_cierre` datetime DEFAULT NULL,
  `monto_venta_cierre` decimal(30,2) DEFAULT NULL,
  `monto_caja` decimal(30,2) DEFAULT NULL,
  `monto_sobrante` decimal(30,2) DEFAULT NULL,
  `cantidad_ventas` int(11) DEFAULT NULL,
  `codigos_ventas` text DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `id_usuario_alta` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `id_usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `cantidad_productos` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_cierre_caja`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `tb_cierre_caja_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `tb_empleado` (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tb_cierre_caja_venta`;

CREATE TABLE `tb_cierre_caja_venta` (
  `id_cierre_caja_venta` int(11) NOT NULL AUTO_INCREMENT,
  `id_cierre_caja` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `fecha_accion` date DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `id_admin_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cierre_caja_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tb_cliente`;

CREATE TABLE `tb_cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_cliente` varchar(50) DEFAULT NULL,
  `apellido_cliente` varchar(50) DEFAULT NULL,
  `telefono_cliente` int(11) DEFAULT NULL,
  `estado_cliente` varchar(20) DEFAULT NULL,
  `observacion` text DEFAULT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tb_compra`;

CREATE TABLE `tb_compra` (
  `id_compra` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_compra` datetime DEFAULT NULL,
  `monto_compra` decimal(30,2) DEFAULT NULL,
  `compra_facturada` varchar(10) DEFAULT NULL,
  `costo_factura` decimal(30,2) DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `tipo_reg` varchar(10) DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_compra`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `tb_compra_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `tb_proveedor` (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_compra` VALUES (1,"2024-01-03 16:12:00","200.00","no","0.00",1,1,"Activo","admin",0,"0000-00-00 00:00:00"),
(2,"2024-01-03 16:14:00","350.00","si","0.00",1,1,"Activo","admin",0,"0000-00-00 00:00:00");


DROP TABLE IF EXISTS `tb_compra_producto`;

CREATE TABLE `tb_compra_producto` (
  `id_compra_producto` int(11) NOT NULL AUTO_INCREMENT,
  `subtotal_compra` decimal(30,2) DEFAULT NULL,
  `cantidad_compra` int(11) DEFAULT NULL,
  `id_compra` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `precio_unit_compra` varchar(30) DEFAULT NULL,
  `precio_unit_compraFacturado` decimal(30,2) DEFAULT NULL,
  `precio_venta_prod` decimal(30,2) DEFAULT NULL,
  `precio_venta_prod_Fact` decimal(30,2) DEFAULT NULL,
  `stock_actual` int(11) DEFAULT NULL,
  `precio_tope` decimal(30,2) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_compra_producto`),
  KEY `id_compra` (`id_compra`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `tb_compra_producto_ibfk_1` FOREIGN KEY (`id_compra`) REFERENCES `tb_compra` (`id_compra`),
  CONSTRAINT `tb_compra_producto_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `tb_producto` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_compra_producto` VALUES (1,"200.00",10,1,1,20,"0.00","30.00","35.00",8,"25.00","Activo"),
(2,"350.00",5,2,3,70,"0.00","80.00","85.00",5,"75.00","Activo");


DROP TABLE IF EXISTS `tb_empleado`;

CREATE TABLE `tb_empleado` (
  `id_empleado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_empleado` varchar(50) DEFAULT NULL,
  `apellido_empleado` varchar(50) DEFAULT NULL,
  `telefono_empleado` int(11) DEFAULT NULL,
  `user_name_emp` varchar(50) DEFAULT NULL,
  `password_emp` varchar(50) DEFAULT NULL,
  `estado_empleado` varchar(20) DEFAULT NULL,
  `observacion_emp` text DEFAULT NULL,
  `permiso_especial` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_empleado` VALUES (1,"LISA","SIMPSON",76667675,"LISA123","lisa123","Activo","ES VENDEDORA",0),
(2,"BART","SIMPSON",778878979,"bart1234","bart1234","Activo","CON PERMISO ESPECIAL",1);


DROP TABLE IF EXISTS `tb_item_proforma`;

CREATE TABLE `tb_item_proforma` (
  `id_item_proforma` int(11) NOT NULL AUTO_INCREMENT,
  `id_proforma` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `producto` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `costo_unitario` decimal(18,2) DEFAULT NULL,
  `subtotal` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`id_item_proforma`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_item_proforma` VALUES (1,1,3,"Parlante k-nup","200.00","600.00"),
(2,1,1,"Escritorio grande","300.00","300.00");


DROP TABLE IF EXISTS `tb_marca`;

CREATE TABLE `tb_marca` (
  `id_marca` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_marca` varchar(50) DEFAULT NULL,
  `estado_marca` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_marca` VALUES (1,"KNUP","Activo"),
(2,"GENIUS","Activo"),
(3,"HP","Activo"),
(4,"TP-LINK","Activo"),
(5,"YAMAHA","Activo"),
(6,"TOSHIBA","Activo");


DROP TABLE IF EXISTS `tb_precio_factura`;

CREATE TABLE `tb_precio_factura` (
  `id_precio_factura` int(11) NOT NULL AUTO_INCREMENT,
  `porcentaje_p_nofacturado` int(11) DEFAULT NULL,
  `porcentaje_p_facturado` int(11) DEFAULT NULL,
  `id_administrador` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_precio_factura`),
  KEY `id_administrador` (`id_administrador`),
  CONSTRAINT `tb_precio_factura_ibfk_1` FOREIGN KEY (`id_administrador`) REFERENCES `tb_administrador` (`id_administrador`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tb_producto`;

CREATE TABLE `tb_producto` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_producto` varchar(100) DEFAULT NULL,
  `codigo_producto` varchar(50) DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `stok_facturado` int(11) DEFAULT NULL,
  `stock_simple` int(11) DEFAULT NULL,
  `estado_producto` varchar(20) DEFAULT NULL,
  `id_marca` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `tipo_reg` varchar(10) DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_modificacion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `id_marca` (`id_marca`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `tb_producto_ibfk_1` FOREIGN KEY (`id_marca`) REFERENCES `tb_marca` (`id_marca`),
  CONSTRAINT `tb_producto_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `tb_categoria` (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_producto` VALUES (1,"MOUSE KNUP-100","KP-100","MOUSE GAMER",0,0,"Activo",1,4,"emp",2,"2024-01-03 15:46:00",0,"0000-00-00 00:00:00","2024-01-03 15:46:00"),
(2,"PARLANTE KP-800","KP-800","PARLANTE DE FUERTE VOLUMEN",0,0,"Activo",1,3,"emp",2,"2024-01-03 15:47:00",0,"0000-00-00 00:00:00","2024-01-03 15:47:00"),
(3,"TECLADO GENIUS-G-100","G-100","TECLADO DE LOS FINOS",0,0,"Activo",2,2,"emp",2,"2024-01-03 15:47:00",0,"0000-00-00 00:00:00","2024-01-03 15:47:00"),
(4,"TECLADO YAMAHA YM-11","YM-11","TECLADO SEMIPROFESIONAL",0,0,"Activo",5,1,"emp",2,"2024-01-03 15:50:00",0,"0000-00-00 00:00:00","2024-01-03 15:50:00"),
(5,"PARLANTE TOSHIBA-T200","T200","PARLANTE PARA PC",0,0,"Activo",6,3,"emp",2,"2024-01-03 15:53:00",0,"0000-00-00 00:00:00","2024-01-03 15:53:00");


DROP TABLE IF EXISTS `tb_proforma`;

CREATE TABLE `tb_proforma` (
  `id_proforma` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_proforma` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `fecha_proceso` date DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `usuario_alta` int(11) DEFAULT NULL,
  `tipo_usuario` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `total_costo` decimal(18,2) DEFAULT NULL,
  `estado` char(1) DEFAULT NULL,
  PRIMARY KEY (`id_proforma`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tb_proforma` VALUES (1,"Alcaldia de Saavedra","2024-01-03","2024-01-03 18:38:00",2,"empl",0,"900.00","A");


DROP TABLE IF EXISTS `tb_proveedor`;

CREATE TABLE `tb_proveedor` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_proveedor` varchar(50) DEFAULT NULL,
  `apellido_proveedor` varchar(50) DEFAULT NULL,
  `telefono_proveedor` int(11) DEFAULT NULL,
  `estado_proveedor` varchar(20) DEFAULT NULL,
  `observacion` text DEFAULT NULL,
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_proveedor` VALUES (1,"PROV GLABAL","GLOBAL",45676543,"Activo","");


DROP TABLE IF EXISTS `tb_sucursal`;

CREATE TABLE `tb_sucursal` (
  `id_sucursal` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_suc` varchar(50) DEFAULT NULL,
  `descripcion_suc` varchar(100) DEFAULT NULL,
  `contacto` varchar(50) DEFAULT NULL,
  `estado_suc` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_sucursal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tb_transferencia_stock_envio`;

CREATE TABLE `tb_transferencia_stock_envio` (
  `id_transferencia_envio` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_transferencia_enviada` datetime DEFAULT NULL,
  `cantidad_envio` int(11) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `descripcion_trans_envio` varchar(200) DEFAULT NULL,
  `id_sucursal_destino` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_transferencia_envio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tb_transferencia_stock_recibido`;

CREATE TABLE `tb_transferencia_stock_recibido` (
  `id_transferencia_recibido` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_trn_recibido` datetime DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `cantidad_recibida` int(11) DEFAULT NULL,
  `estado_recibida` varchar(10) DEFAULT NULL,
  `descripcion_recibido` varchar(200) DEFAULT NULL,
  `id_sucursal_origen` int(11) DEFAULT NULL,
  `codigo_de_envio` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_transferencia_recibido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tb_venta`;

CREATE TABLE `tb_venta` (
  `id_venta` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_venta` datetime DEFAULT NULL,
  `monto_venta` decimal(30,2) DEFAULT NULL,
  `venta_facturada` varchar(20) DEFAULT NULL,
  `precio_facturaV` decimal(30,2) DEFAULT NULL,
  `tipo_venta` varchar(20) DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_venta`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `tb_venta_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `tb_empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_venta` VALUES (16,"2024-01-03 17:18:00","30.00","no","0.00","empl",2,"Activo",0,"0000-00-00 00:00:00"),
(17,"2024-01-03 17:19:00","30.00","no","0.00","empl",2,"Activo",0,"0000-00-00 00:00:00");


DROP TABLE IF EXISTS `tb_venta_cliente`;

CREATE TABLE `tb_venta_cliente` (
  `id_venta_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_venta_cliente`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `tb_venta_cliente_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tb_cliente` (`id_cliente`),
  CONSTRAINT `tb_venta_cliente_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `tb_venta` (`id_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `tb_venta_producto`;

CREATE TABLE `tb_venta_producto` (
  `id_venta_producto` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_prod` varchar(50) DEFAULT NULL,
  `subtotal_venta` decimal(30,2) DEFAULT NULL,
  `cantidad_prod` int(11) DEFAULT NULL,
  `ventaP_facturada` varchar(10) DEFAULT NULL,
  `precio_factura` decimal(30,2) DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `precio_unitario_venta` decimal(30,2) DEFAULT NULL,
  `precio_compra_prod` decimal(30,2) DEFAULT NULL,
  `precio_venta_establecido` decimal(30,2) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_venta_producto`),
  KEY `id_compra_producto` (`id_compra_producto`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `tb_venta_producto_ibfk_1` FOREIGN KEY (`id_compra_producto`) REFERENCES `tb_compra_producto` (`id_compra_producto`),
  CONSTRAINT `tb_venta_producto_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `tb_venta` (`id_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tb_venta_producto` VALUES (1,"","30.00",1,0,"0.00",1,16,"30.00","20.00","30.00","Activo"),
(2,"","30.00",1,0,"0.00",1,17,"30.00","20.00","30.00","Activo");


SET foreign_key_checks = 1;

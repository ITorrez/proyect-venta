SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `tb_administrador`;

CREATE TABLE `tb_administrador` (
  `id_administrador` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_administrador` varchar(50) DEFAULT NULL,
  `apellido_administrador` varchar(50) DEFAULT NULL,
  `telefono_administrador` int(11) DEFAULT NULL,
  `user_admin` varchar(50) DEFAULT NULL,
  `password_admin` varchar(50) DEFAULT NULL,
  `estado_admin` varchar(20) DEFAULT NULL,
  `observacion_admin` text,
  PRIMARY KEY (`id_administrador`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_administrador` VALUES (1,"Admin","administrador",67654333,"sonido123","sonido123","Activo","es el admin del sistema");


DROP TABLE IF EXISTS `tb_categoria`;

CREATE TABLE `tb_categoria` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_categoria` varchar(50) DEFAULT NULL,
  `estado_cat` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_categoria` VALUES (1,"PARLANTES","Activo"),
(2,"TECLADOS","Activo"),
(3,"MOUSE","Activo"),
(4,"EQUIPO DE SONIDO","Activo");


DROP TABLE IF EXISTS `tb_cierre_caja`;

CREATE TABLE `tb_cierre_caja` (
  `id_cierre_caja` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_cierre` datetime DEFAULT NULL,
  `monto_venta_cierre` decimal(30,2) DEFAULT NULL,
  `monto_caja` decimal(30,2) DEFAULT NULL,
  `monto_sobrante` decimal(30,2) DEFAULT NULL,
  `cantidad_ventas` int(11) DEFAULT NULL,
  `codigos_ventas` text,
  `id_empleado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_cierre_caja`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `tb_cierre_caja_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `tb_empleado` (`id_empleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `tb_cliente`;

CREATE TABLE `tb_cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_cliente` varchar(50) DEFAULT NULL,
  `apellido_cliente` varchar(50) DEFAULT NULL,
  `telefono_cliente` int(11) DEFAULT NULL,
  `estado_cliente` varchar(20) DEFAULT NULL,
  `observacion` text,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_cliente` VALUES (1,"JULIO ","LEAÑOS",756754676,"Activo","ES UN CLIENTE "),
(2,"MARIO","FERNANDES",78794565,"Activo","ES UN CLIENTE"),
(3,"LIDIA","GUEILER",77554444,"Activo","ES CLI"),
(4,"LAURA","FRIAS",6659494,"Activo","ES CLI");


DROP TABLE IF EXISTS `tb_compra`;

CREATE TABLE `tb_compra` (
  `id_compra` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_compra` datetime DEFAULT NULL,
  `monto_compra` decimal(30,2) DEFAULT NULL,
  `compra_facturada` varchar(10) DEFAULT NULL,
  `costo_factura` decimal(30,2) DEFAULT NULL,
  `id_administrador` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_compra`),
  KEY `id_administrador` (`id_administrador`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `tb_compra_ibfk_1` FOREIGN KEY (`id_administrador`) REFERENCES `tb_administrador` (`id_administrador`),
  CONSTRAINT `tb_compra_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `tb_proveedor` (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_compra` VALUES (1,"2022-06-22 22:32:00","1600.00","no","0.00",1,1,"Activo"),
(2,"2022-07-12 22:17:00","250.00","no","0.00",1,2,"Activo"),
(3,"2022-07-12 22:20:00","1000.00","no","0.00",1,1,"Activo"),
(4,"2022-07-12 22:37:00","1200.00","no","0.00",1,1,"Activo"),
(5,"2022-07-13 01:38:00","400.00","si","0.00",1,2,"Activo"),
(6,"2022-07-30 00:55:00","1800.00","no","0.00",1,1,"Activo");


DROP TABLE IF EXISTS `tb_compra_producto`;

CREATE TABLE `tb_compra_producto` (
  `id_compra_producto` int(11) NOT NULL AUTO_INCREMENT,
  `subtotal_compra` decimal(30,2) DEFAULT NULL,
  `cantidad_compra` int(11) DEFAULT NULL,
  `id_compra` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `precio_unit_compra` varchar(30) DEFAULT NULL,
  `precio_unit_compraFacturado` decimal(30,2) DEFAULT NULL,
  `precio_venta_prod` decimal(30,2) DEFAULT NULL,
  `precio_venta_prod_Fact` decimal(30,2) DEFAULT NULL,
  `stock_actual` int(11) DEFAULT NULL,
  `precio_tope` decimal(30,2) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_compra_producto`),
  KEY `id_compra` (`id_compra`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `tb_compra_producto_ibfk_1` FOREIGN KEY (`id_compra`) REFERENCES `tb_compra` (`id_compra`),
  CONSTRAINT `tb_compra_producto_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `tb_producto` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_compra_producto` VALUES (1,"1600.00",2,1,1,800,"0.00","900.00","970.00",2,"890.00","Activo"),
(2,"250.00",5,2,3,50,"0.00","65.00","75.00",2,"60.00","Activo"),
(3,"1000.00",5,3,5,200,"0.00","250.00","290.00",4,"240.00","Activo"),
(4,"1200.00",3,4,4,400,"0.00","500.00","580.00",2,"450.00","Activo"),
(5,"400.00",2,5,2,200,"200.00","240.00","290.00",1,"230.00","Activo"),
(6,"1800.00",2,6,1,900,"0.00","980.00","1100.00",2,"970.00","Activo");


DROP TABLE IF EXISTS `tb_empleado`;

CREATE TABLE `tb_empleado` (
  `id_empleado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_empleado` varchar(50) DEFAULT NULL,
  `apellido_empleado` varchar(50) DEFAULT NULL,
  `telefono_empleado` int(11) DEFAULT NULL,
  `user_name_emp` varchar(50) DEFAULT NULL,
  `password_emp` varchar(50) DEFAULT NULL,
  `estado_empleado` varchar(20) DEFAULT NULL,
  `observacion_emp` text,
  PRIMARY KEY (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_empleado` VALUES (1,"Andres","lopez",876544333,"andres123","andres123","Activo","es encargado de venta"),
(2,"Bart","Simpson",76786234,"bart123","bart123","Activo","Es vendedor"),
(3,"Lisa ","simpson",75673222,"lisa123","lisa123","Activo","es vendedora");


DROP TABLE IF EXISTS `tb_marca`;

CREATE TABLE `tb_marca` (
  `id_marca` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_marca` varchar(50) DEFAULT NULL,
  `estado_marca` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_marca` VALUES (1,"KNUP","Activo"),
(2,"PIONER","Activo"),
(3,"SONY","Activo"),
(4,"DELUX","Activo"),
(5,"YAMAHA","Activo");


DROP TABLE IF EXISTS `tb_precio_factura`;

CREATE TABLE `tb_precio_factura` (
  `id_precio_factura` int(11) NOT NULL AUTO_INCREMENT,
  `porcentaje_p_nofacturado` int(11) DEFAULT NULL,
  `porcentaje_p_facturado` int(11) DEFAULT NULL,
  `id_administrador` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_precio_factura`),
  KEY `id_administrador` (`id_administrador`),
  CONSTRAINT `tb_precio_factura_ibfk_1` FOREIGN KEY (`id_administrador`) REFERENCES `tb_administrador` (`id_administrador`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `tb_producto`;

CREATE TABLE `tb_producto` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_producto` varchar(100) DEFAULT NULL,
  `codigo_producto` varchar(50) DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  `stok_facturado` int(11) DEFAULT NULL,
  `stock_simple` int(11) DEFAULT NULL,
  `estado_producto` varchar(20) DEFAULT NULL,
  `id_marca` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `id_marca` (`id_marca`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `tb_producto_ibfk_1` FOREIGN KEY (`id_marca`) REFERENCES `tb_marca` (`id_marca`),
  CONSTRAINT `tb_producto_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `tb_categoria` (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_producto` VALUES (1,"TECLADO YAMAHA YM2500","YM2500","ES UN TECLADO NEGRO",0,0,"Activo",5,2),
(2,"PARLANTE DELUX DX123","DX123","PARLANTE PARA PC",0,0,"Activo",4,1),
(3,"MOUSE  DELUX L345","L345","MOUSE GAMER",0,0,"Activo",4,3),
(4,"TOCA SINTA PD564","DP564","TOCA SINTA PARA AUTOS",0,0,"Activo",2,4),
(5,"PARLANTE KNUP KP56","KP56","PARLANTE EXTERIOR",0,0,"Activo",1,1);


DROP TABLE IF EXISTS `tb_proveedor`;

CREATE TABLE `tb_proveedor` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_proveedor` varchar(50) DEFAULT NULL,
  `apellido_proveedor` varchar(50) DEFAULT NULL,
  `telefono_proveedor` int(11) DEFAULT NULL,
  `estado_proveedor` varchar(20) DEFAULT NULL,
  `observacion` text,
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_proveedor` VALUES (1,"PROMOLUX","PROMOLUX",7678655,"Activo","ES UNA DISTRIBUIDORA DE SANTA CRUZ"),
(2,"ANTONIO","ROJAS",756753333,"Activo","ES UN DISTRIBUIDOR DE SONIDO");


DROP TABLE IF EXISTS `tb_sucursal`;

CREATE TABLE `tb_sucursal` (
  `id_sucursal` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_suc` varchar(50) DEFAULT NULL,
  `descripcion_suc` varchar(100) DEFAULT NULL,
  `contacto` varchar(50) DEFAULT NULL,
  `estado_suc` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_sucursal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `tb_transferencia_stock_envio`;

CREATE TABLE `tb_transferencia_stock_envio` (
  `id_transferencia_envio` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_transferencia_enviada` datetime DEFAULT NULL,
  `cantidad_envio` int(11) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `descripcion_trans_envio` varchar(200) DEFAULT NULL,
  `id_sucursal_destino` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_transferencia_envio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `tb_transferencia_stock_recibido`;

CREATE TABLE `tb_transferencia_stock_recibido` (
  `id_transferencia_recibido` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_trn_recibido` datetime DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `cantidad_recibida` int(11) DEFAULT NULL,
  `estado_recibida` varchar(10) DEFAULT NULL,
  `descripcion_recibido` varchar(200) DEFAULT NULL,
  `id_sucursal_origen` int(11) DEFAULT NULL,
  `codigo_de_envio` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_transferencia_recibido`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `tb_venta`;

CREATE TABLE `tb_venta` (
  `id_venta` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_venta` datetime DEFAULT NULL,
  `monto_venta` decimal(30,2) DEFAULT NULL,
  `venta_facturada` varchar(20) DEFAULT NULL,
  `precio_facturaV` decimal(30,2) DEFAULT NULL,
  `tipo_venta` varchar(20) DEFAULT NULL,
  `id_empleado` int(11) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `usuario_baja` int(11) DEFAULT '0',
  `fecha_baja` datetime DEFAULT NULL,
  PRIMARY KEY (`id_venta`),
  KEY `id_empleado` (`id_empleado`),
  CONSTRAINT `tb_venta_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `tb_empleado` (`id_empleado`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_venta` VALUES (1,"2022-07-29 23:59:00","65.00","no","0.00","empl",1,"Activo",0,NULL),
(2,"2022-07-30 00:00:00","65.00","no","0.00","empl",1,"Activo",0,NULL),
(3,"2022-09-11 23:59:00","500.00","no","0.00","empl",1,"Inactivo",0,NULL),
(4,"2022-09-12 00:07:00","500.00","no","0.00","empl",2,"Activo",0,NULL),
(5,"2022-09-13 22:52:00","555.00","no","0.00","empl",2,"Activo",0,NULL),
(6,"2022-09-14 00:24:00","500.00","no","0.00","empl",2,"Inactivo",0,"2022-09-14 00:28:00"),
(7,"2022-09-14 00:30:00","250.00","no","0.00","empl",2,"Inactivo",1,"2022-09-14 00:31:00");


DROP TABLE IF EXISTS `tb_venta_cliente`;

CREATE TABLE `tb_venta_cliente` (
  `id_venta_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_venta_cliente`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `tb_venta_cliente_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `tb_cliente` (`id_cliente`),
  CONSTRAINT `tb_venta_cliente_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `tb_venta` (`id_venta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



DROP TABLE IF EXISTS `tb_venta_producto`;

CREATE TABLE `tb_venta_producto` (
  `id_venta_producto` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_prod` varchar(50) DEFAULT NULL,
  `subtotal_venta` decimal(30,2) DEFAULT NULL,
  `cantidad_prod` int(11) DEFAULT NULL,
  `ventaP_facturada` varchar(10) DEFAULT NULL,
  `precio_factura` decimal(30,2) DEFAULT NULL,
  `id_compra_producto` int(11) DEFAULT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `precio_unitario_venta` decimal(30,2) DEFAULT NULL,
  `precio_compra_prod` decimal(30,2) DEFAULT NULL,
  `precio_venta_establecido` decimal(30,2) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_venta_producto`),
  KEY `id_compra_producto` (`id_compra_producto`),
  KEY `id_venta` (`id_venta`),
  CONSTRAINT `tb_venta_producto_ibfk_1` FOREIGN KEY (`id_compra_producto`) REFERENCES `tb_compra_producto` (`id_compra_producto`),
  CONSTRAINT `tb_venta_producto_ibfk_2` FOREIGN KEY (`id_venta`) REFERENCES `tb_venta` (`id_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `tb_venta_producto` VALUES (1,"ghh","65.00",1,0,"0.00",2,1,"65.00","50.00","65.00","Activo"),
(2,"fggdsd","65.00",1,0,"0.00",2,2,"65.00","50.00","65.00","Activo"),
(3,"KP453333","500.00",2,0,"0.00",3,3,"250.00","200.00","250.00","Inactivo"),
(4,"","500.00",1,0,"0.00",4,4,"500.00","400.00","500.00","Activo"),
(5,"L344522","65.00",1,0,"0.00",2,5,"65.00","50.00","65.00","Activo"),
(6,"KP76677","250.00",1,0,"0.00",3,5,"250.00","200.00","250.00","Activo"),
(7,"DX3422344","240.00",1,0,"0.00",5,5,"240.00","200.00","240.00","Activo"),
(8,"576uhr6yt","500.00",1,0,"0.00",4,6,"500.00","400.00","500.00","Inactivo"),
(9,"ry65y465","250.00",1,0,"0.00",3,7,"250.00","200.00","250.00","Inactivo");


SET foreign_key_checks = 1;
